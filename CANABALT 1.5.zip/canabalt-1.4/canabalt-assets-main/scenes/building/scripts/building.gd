extends Sprite2D

# Preload textures at the top, no need to grab from scene nodes
var SEGMENT_TEXTURES: Array[Texture2D] = [
	preload("res://assets/images/wall1.png"),
	preload("res://assets/images/wall2.png"),
	preload("res://assets/images/wall3.png"),
	preload("res://assets/images/window4.png"),
]
var ROOF_TILE_SCENE = preload("res://scenes/roof_top.tscn")
var OBSTACLE_TEXTURES: Array[Texture2D] = [
	preload("res://assets/images/obstacle1.png"),
	preload("res://assets/images/obstacle2.png"),
	preload("res://assets/images/obstacle3.png"),
]
var SPACE_BETWEEN_BUILDINGS = preload("res://scenes/space_buildings.tscn")
var BUILDING_SHIELD = preload("res://scenes/building_shield.tscn")
var OBSTACLES = preload("res://scenes/obstacles.tscn")

const OBSTACLE_TARGET_SIZE := Vector2(40, 40)  # Target size for obstacles (width x height)

# Constants
const BUILDING_WIDTH_SEGMENTS := 7
const BASE_BUILDING_HEIGHT := 10
const SEGMENT_WIDTH := 48
const SEGMENT_HEIGHT := 16

func _ready() -> void:
	pass # Nothing needed here anymore!

func create_procedural_building(base_pos: Vector2, height_segments: int, width_segments: int = 7, place_obstacles: bool = true) -> Node2D:
	var container = Node2D.new()
	container.name = "Building"
	container.position = base_pos

	var window_rows: Array[int] = []
	var row: int = height_segments - 1
	while row >= 0:
		window_rows.append(row)
		row -= 4

	for y in range(height_segments):
		var shield_instance = BUILDING_SHIELD.instantiate()
		shield_instance.position = Vector2(-SEGMENT_WIDTH, -y * SEGMENT_HEIGHT)
		container.add_child(shield_instance)

		var last_was_window := false

		for x in range(width_segments):
			var is_window_row := y in window_rows
			var is_inner_column := x > 0 and x < width_segments - 1
			var place_window := is_window_row and is_inner_column and not last_was_window and randf() > 0.03

			var texture: Texture2D
			if place_window:
				texture = SEGMENT_TEXTURES[3]
			else:
				texture = SEGMENT_TEXTURES[randi() % 3]

			last_was_window = place_window
			var sprite = Sprite2D.new()
			sprite.texture = texture
			sprite.position = Vector2(x * SEGMENT_WIDTH, -y * SEGMENT_HEIGHT)
			container.add_child(sprite)

	var roof_y := -(height_segments * SEGMENT_HEIGHT)
	for x in range(width_segments):
		var roof_tile = ROOF_TILE_SCENE.instantiate()
		roof_tile.position = Vector2(x * SEGMENT_WIDTH, roof_y)
		container.add_child(roof_tile)

	var space = SPACE_BETWEEN_BUILDINGS.instantiate()
	space.position = Vector2(width_segments * SEGMENT_WIDTH, roof_y)
	container.add_child(space)

	if place_obstacles:
		place_obstacle_on_roof(container, roof_y - 27, width_segments)

	return container

func place_obstacle_on_roof(building: Node2D, roof_y: float, width_segments: int = 7):
	var obstacle_instance = OBSTACLES.instantiate()
	obstacle_instance.name = "Obstacle"  # Important for tracking!
	var random_x := randi() % (width_segments * SEGMENT_WIDTH)
	obstacle_instance.position = Vector2(random_x, roof_y)
	building.add_child(obstacle_instance)
