extends Node2D

const MIN_GAP := 0
const MAX_GAP := 300
const INITIAL_BUILDINGS := 3
const MAX_OBSTACLES := 2

var active_buildings: Array = []
var active_obstacles := 0  # Track global obstacle count

# Load the building script and create an instance of it
var building_script = preload("res://scripts/building.gd")
var building_instance: Node = building_script.new()

func _ready():
	randomize()
	var screen_size: Vector2 = get_viewport().get_visible_rect().size
	var x_offset: float = 0.0
	var base_y: float = screen_size.y
	var building_count: int = 0

	while x_offset < screen_size.x + 336:
		var height_segments = 10
		var width_segments = 7
		var place_obstacles := (building_count >= INITIAL_BUILDINGS and active_obstacles < MAX_OBSTACLES)

		var building = building_instance.create_procedural_building(
			Vector2(x_offset, base_y - 15),
			height_segments,
			width_segments,
			place_obstacles
		)

		if place_obstacles:
			active_obstacles += 1

		add_child(building)
		active_buildings.append({
			"node": building,
			"width": width_segments * 48
		})

		building_count += 1
		var gap = 0 if building_count <= INITIAL_BUILDINGS else (randi() % (MAX_GAP - MIN_GAP + 1)) + MIN_GAP
		x_offset += width_segments * 48 + gap

func _process(delta):
	var screen_size: Vector2 = get_viewport().get_visible_rect().size

	for entry in active_buildings:
		entry["node"].position.x -= Globl.MOVE_SPEED * delta

	for i in range(active_buildings.size() - 1, -1, -1):
		var entry = active_buildings[i]
		if entry["node"].position.x + entry["width"] < 0:
			# Count how many obstacles were in this building before freeing
			for child in entry["node"].get_children():
				if child.name == "Obstacle":  # or use `is_in_group("obstacle")`
					active_obstacles = max(0, active_obstacles - 1)
			entry["node"].queue_free()
			active_buildings.remove_at(i)

	if active_buildings.size() > 0:
		var last_entry = active_buildings[-1]
		var last_x_end = last_entry["node"].position.x + last_entry["width"]
		var target_spawn_x = last_x_end + (randi() % (MAX_GAP - MIN_GAP + 1)) + MIN_GAP

		if target_spawn_x < screen_size.x + 336:
			var height_segments = (randi() % 16) + 6
			var width_segments = (randi() % 5) + 5
			var place_obstacles := active_obstacles < MAX_OBSTACLES

			var new_building = building_instance.create_procedural_building(
				Vector2(screen_size.x + 336, screen_size.y - 15),
				height_segments,
				width_segments,
				place_obstacles
			)

			if place_obstacles:
				active_obstacles += 1

			add_child(new_building)
			active_buildings.append({
				"node": new_building,
				"width": width_segments * 48
			})
