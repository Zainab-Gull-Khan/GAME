extends Sprite2D


func _on_obs_2d_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	if area.name == "player2D":
		var tween := create_tween()
		var target_pos = global_position + Vector2(randf_range(-100, -50), -100)

		tween.tween_property(self, "global_position", target_pos, 0.4)\
			.set_trans(Tween.TRANS_SINE)\
			.set_ease(Tween.EASE_OUT)

		tween.tween_property(self, "modulate:a", 0.0, 0.4)\
			.set_trans(Tween.TRANS_SINE)\
			.set_ease(Tween.EASE_IN)

		tween.connect("finished", Callable(self, "_on_tween_finished"))

func _on_tween_finished():
	queue_free()
