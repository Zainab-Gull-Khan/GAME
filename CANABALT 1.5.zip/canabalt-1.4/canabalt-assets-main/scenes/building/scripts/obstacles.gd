extends Node2D

const OBSTACLE_TARGET_SIZE = Vector2(40, 40)  # Size to scale

var OBSTACLE_TEXTURES: Array[Texture2D] = []

func _ready():
	# Get textures from the three child sprites
	OBSTACLE_TEXTURES = [
		$obs1.texture,
		$obs2.texture,
		$obs3.texture
	]

	# Hide all obstacles at start
	$obs1.visible = false
	$obs2.visible = false
	$obs3.visible = false

	# Randomly pick one
	var index = randi() % OBSTACLE_TEXTURES.size()
	var chosen_sprite: Sprite2D = get_node("obs" + str(index + 1))

	# Show the chosen sprite
	chosen_sprite.visible = true

	# Scale it and set its position
	resize_and_position_sprite(chosen_sprite)

func resize_and_position_sprite(sprite: Sprite2D):
	if sprite.texture:
		var original_size = sprite.texture.get_size()
		sprite.scale = OBSTACLE_TARGET_SIZE / original_size
		
