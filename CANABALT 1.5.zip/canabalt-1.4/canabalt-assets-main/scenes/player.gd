extends CharacterBody2D

const GRAVITY = 500.0
const MAX_JUMP_SPEED = -150.0  # Strongest jump
const MIN_JUMP_SPEED = -350.0  # Lightest jump
const MOVE_SPEED = 100.0

@onready var anim_sprite = $AnimatedSprite2D
var last_position: Vector2
var jump_time = 0.0
var max_jump_duration = 0.3
var is_jumping = false  # New variable!

func _ready():
	last_position = global_position

func _physics_process(delta):
	velocity.y += GRAVITY * delta

	if is_on_floor():
		is_jumping = false  # Reset jump state if on floor
		if Input.is_action_just_pressed("ui_accept"):
			jump_time = 0.0
			velocity.y = MIN_JUMP_SPEED
			is_jumping = true
			anim_sprite.play("jump")

	# Control jump height while ascending
	if is_jumping:
		if Input.is_action_pressed("ui_accept") and jump_time < max_jump_duration:
			jump_time += delta
			# Increase the jump speed the longer space is held
			velocity.y = lerp(MAX_JUMP_SPEED, MIN_JUMP_SPEED, jump_time / max_jump_duration)
		else:
			is_jumping = false  # Stop boosting jump when released or max duration reached

	# Animation based on velocity
	if velocity.y < 0:
		anim_sprite.play("jumping")
	elif velocity.y > 0:
		anim_sprite.play("running")

	if position.y > get_viewport().get_visible_rect().size.y + 100:
		get_tree().change_scene_to_file("res://canabalt-assets-main/scenes/exit.tscn")

	move_and_slide()

	# Distance tracking
	var distance_this_frame = global_position.x - last_position.x
	GameManager.distance_traveled += distance_this_frame
	last_position = global_position

	if GameManager.distance_traveled >= GameManager.next_distance_checkpoint:
		GameManager.score += GameManager.POINTS_PER_DISTANCE
		GameManager.next_distance_checkpoint += 500
		velocity.y += GRAVITY * delta

	var collision = move_and_collide(velocity * delta)
	
	if collision and collision.get_collider().is_in_group("crates"):
		slow_down()

func slow_down():
	velocity.x *= 0.5

	
