extends Control
var music: AudioStreamPlayer2D
func _ready():
	$AudioStreamPlayer2D.play()
func _on_play_pressed() -> void:
	$AudioStreamPlayer2D.stop()
	get_tree().change_scene_to_file("res://canabalt-assets-main/scenes/main.tscn")
func _on_quit_pressed() -> void:
	get_tree().quit()
	
