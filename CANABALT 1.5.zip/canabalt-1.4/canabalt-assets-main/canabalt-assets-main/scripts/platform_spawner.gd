extends Node2D

@export var spawn_interval := 400  # distance between platforms
@export var move_speed := 100.0


var last_platform_x := 0

func _ready():
	randomize()
	spawn_platform(position.x)

func _process(delta):
	if get_child_count() == 0 or last_platform_x < get_viewport_rect().size.x:
		spawn_platform(last_platform_x + spawn_interval)

func spawn_platform(x_position):
	last_platform_x = x_position
	
	# (You spawn your platforms here already — keep that code)

	
