#extends Node2D
#
## Texture Constants
#const ROOF_TEXTURE := preload("res://canabalt-assets-main/images/roof1.png")
#const ROOF_TEXTURE_END := preload("res://canabalt-assets-main/images/roof4.png")
#const WALL_TEXTURES := [
	#preload("res://canabalt-assets-main/images/wall1.png"),
	#preload("res://canabalt-assets-main/images/wall2.png"),
	#preload("res://canabalt-assets-main/images/wall3.png"),
	#preload("res://canabalt-assets-main/images/wall4.png")
#]
#const WINDOW_TEXTURE := preload("res://canabalt-assets-main/images/window1.png")
#
## Building Configuration
#const SEGMENT_WIDTH := 48
#const SEGMENT_HEIGHT := 16
#@export var height_segments := 10
#@export var window_interval := 2
#@export var move_speed := 500.0
#@export var height_range := Vector2(200, 400)
#@export var gap_width_range := Vector2(250, 500)
#
## Wrapping Variables
#var screen_size : Vector2
#var building_width : float
#var building_parts : Array = []
#
#func _ready():
	#randomize()
	#screen_size = get_viewport().get_visible_rect().size
	#generate_building()
	#building_width = (ceil(screen_size.x / SEGMENT_WIDTH) + 2) * SEGMENT_WIDTH
	#position = Vector2(-SEGMENT_WIDTH * 2, 0)
#
#func _process(delta):
	#for part in building_parts:
		#part.position.x -= move_speed * delta
		#if part.position.x < -SEGMENT_WIDTH:
			#part.position.x += building_width + SEGMENT_WIDTH
#
#func generate_building():
	## Clear previous building
	#for child in get_children():
		#child.queue_free()
	#building_parts.clear()
#
	#var segment_count = ceil(screen_size.x / SEGMENT_WIDTH) + 4
	#var base_y = screen_size.y
	#var x = 0
	#var last_column_had_windows = false  # Track consecutive window columns
	#
	#while x < segment_count:
		#var random=randf_range(50,150)
		#if x % int(random) == 0:  # Skip every 100 segments to create gaps
			#var gap_width = randf_range(gap_width_range.x, gap_width_range.y)
			#x += int(gap_width / SEGMENT_WIDTH)
			#last_column_had_windows = false  # Reset window tracking after a gap
			#continue
#
		#var random_height = randf_range(height_range.x, height_range.y)
		#var is_first_or_last_column = (x <= 1 or x == segment_count - 1)
		#var this_column_has_windows = false  # Assume no windows
#
		#for y in range(height_segments):
			#var is_last_row = (y == height_segments - 1)
			#var is_window_row = (y % window_interval == 0)
#
			## Allow windows only if it's not the first/last column, not last row, and not consecutive window column
			#var allow_window = is_window_row and not is_last_row and not is_first_or_last_column and not last_column_had_windows and x != segment_count - 1         
#
			## Create StaticBody2D for collision-enabled segment
			#var platform_segment = StaticBody2D.new()
			#add_child(platform_segment)
			#building_parts.append(platform_segment)
#
			## Add Sprite2D
			#var sprite = Sprite2D.new()
			#sprite.position = Vector2.ZERO
#
			#if is_last_row:
				#sprite.texture = ROOF_TEXTURE_END if is_first_or_last_column else ROOF_TEXTURE
			#elif allow_window:
				#sprite.texture = WINDOW_TEXTURE
				#this_column_has_windows = true
			#else:
				## Use specific wall texture for first/last column, random for others
				#sprite.texture = WALL_TEXTURES[2] if is_first_or_last_column else WALL_TEXTURES[randi() % WALL_TEXTURES.size()]
			#
			#platform_segment.add_child(sprite)
#
			## Add collision only for top row
			#if is_last_row:
				#var collision = CollisionShape2D.new()
				#var shape = RectangleShape2D.new()
				#shape.size = Vector2(SEGMENT_WIDTH, SEGMENT_HEIGHT)
				#collision.shape = shape
				#collision.position = Vector2(SEGMENT_WIDTH / 2, SEGMENT_HEIGHT / 2)
				#platform_segment.add_child(collision)
#
			## Position segment
			#platform_segment.position = Vector2(x * SEGMENT_WIDTH, base_y - (y * SEGMENT_HEIGHT))
#
		#last_column_had_windows = this_column_has_windows
		#x += 1

extends Node2D

# Texture Constants
const ROOF_TEXTURE := preload("res://canabalt-assets-main/images/roof1.png")
const ROOF_TEXTURE_END := preload("res://canabalt-assets-main/images/roof4.png")
const WALL_TEXTURES := [
	preload("res://canabalt-assets-main/images/wall1.png"),
	preload("res://canabalt-assets-main/images/wall2.png"),
	preload("res://canabalt-assets-main/images/wall3.png"),
	preload("res://canabalt-assets-main/images/wall4.png")
]
const WINDOW_TEXTURE := preload("res://canabalt-assets-main/images/window1.png")

# Building Configuration
const SEGMENT_WIDTH := 48
const SEGMENT_HEIGHT := 16
@export var height_segments := 10
@export var window_interval := 2
@export var move_speed := 500.0
@export var height_range := Vector2(200, 400)
@export var gap_width_range := Vector2(250, 500)

# Wrapping Variables
var screen_size : Vector2
var building_width : float
var building_parts : Array = []

func _ready():
	randomize()
	screen_size = get_viewport().get_visible_rect().size
	generate_building()
	building_width = (ceil(screen_size.x / SEGMENT_WIDTH) + 2) * SEGMENT_WIDTH
	position = Vector2(-SEGMENT_WIDTH * 2, 0)

func _process(delta):
	for part in building_parts:
		part.position.x -= move_speed * delta
		if part.position.x < -SEGMENT_WIDTH:
			part.position.x += building_width + SEGMENT_WIDTH

func generate_building():
	# Clear previous building
	for child in get_children():
		child.queue_free()
	building_parts.clear()

	var segment_count = ceil(screen_size.x / SEGMENT_WIDTH) + 4
	var base_y = screen_size.y
	var x = 0
	var last_column_had_windows = false  # Track consecutive window columns
	var random = randf_range(50, 100)

	while x < segment_count:
		if x % int(random) == 0:  # Skip random segments to create gaps
			var gap_width = randf_range(gap_width_range.x, gap_width_range.y)
			x += int(gap_width / SEGMENT_WIDTH)
			last_column_had_windows = false
			continue

		var random_height = randf_range(height_range.x, height_range.y)
		var is_first_or_last_column = (x == 1 or x == segment_count - 1)
		var this_column_has_windows = false

		for y in range(height_segments):
			var is_last_row = (y == height_segments - 1)
			var is_window_row = (y % window_interval == 0)

			# Allow windows only if not first/last column, not last row, and not consecutive window column
			var allow_window = is_window_row and not is_last_row and not is_first_or_last_column and not last_column_had_windows and x != segment_count - 1

			# Create StaticBody2D for collision-enabled segment
			var platform_segment = StaticBody2D.new()
			add_child(platform_segment)
			building_parts.append(platform_segment)

			# Add Sprite2D
			var sprite = Sprite2D.new()
			sprite.position = Vector2.ZERO

			if is_last_row:
				sprite.texture = ROOF_TEXTURE_END if is_first_or_last_column else ROOF_TEXTURE
			elif allow_window:
				sprite.texture = WINDOW_TEXTURE
				this_column_has_windows = true
			else:
				# Use specific wall texture for first/last column, random for others
				sprite.texture = WALL_TEXTURES[2] if is_first_or_last_column else WALL_TEXTURES[randi() % WALL_TEXTURES.size()]

			platform_segment.add_child(sprite)

			# Add collision only for top row
			if is_last_row:
				var collision = CollisionShape2D.new()
				var shape = RectangleShape2D.new()
				shape.size = Vector2(SEGMENT_WIDTH, SEGMENT_HEIGHT)
				collision.shape = shape
				collision.position = Vector2(SEGMENT_WIDTH / 2, SEGMENT_HEIGHT / 2)
				platform_segment.add_child(collision)

			# Position segment
			platform_segment.position = Vector2(x * SEGMENT_WIDTH, base_y - (y * SEGMENT_HEIGHT))

		last_column_had_windows = this_column_has_windows
		x += 1
