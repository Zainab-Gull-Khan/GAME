extends Node

var score = 0
var survival_time = 0
var distance_traveled: float = 0
var next_distance_checkpoint: float = 500

const POINTS_PER_DISTANCE = 20
const JUMP_BONUS = 50


@onready var score_timer = $score_timer  # Reference to the Timer node
@onready var score_label = $score  # Reference to the Label node for displaying score
@onready var spawn_area = $platform  # Assuming your Building node exists in the scene


func _ready():
	if score_timer:
		print("Timer found.")  # Confirm the timer is found
		score_timer.wait_time = 1  # Set timer interval to 1 second
		score_timer.one_shot = false  # Ensure it's not one-shot
		score_timer.start()  # Start the timer
	else:
		print("Error: score_timer not found.")

func _on_score_timer_timeout():
	score += 1
	print("Timer triggered! Score:", score)  # This will print every second
	# Update the label with the current score
	if score_label:
		score_label.text = "Score: " + str(score)  # Update the label with the score
