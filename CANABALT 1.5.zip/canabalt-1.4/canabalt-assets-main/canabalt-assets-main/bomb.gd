extends Sprite2D

@export var fall_speed : float = 400.0

func _process(delta):
	position.y += fall_speed * delta
	if position.y > get_viewport().size.y:
		queue_free()


func _on_bomb_rigid_body_2d_body_entered(body: Node) -> void:
	if body.name == "Player":
		body.die()  
