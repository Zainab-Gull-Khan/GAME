extends ParallaxBackground

@export var scroll_speed = Vector2(500, 0)
var is_moving = true  # Flag to control movement

# This method will stop the movement when called
func stop_movement():
	is_moving = false

func _process(delta):
	if is_moving:
		scroll_offset -= scroll_speed * delta  # Update the scroll_offset if moving
