extends Sprite2D

@export var fall_speed : float = 300.0  # Speed at which the bomb falls (pixels per second)
var gravity : float = 800.0  # Simulate gravity (you can adjust this)
var velocity : Vector2 = Vector2.ZERO  # Initialize velocity vector

func _ready():
	pass

func _process(delta):
	# Apply gravity to the velocity on the y-axis
	velocity.y += gravity * delta  # Gravity effect (downward acceleration)

	# Update the position of the bomb based on its velocity
	position += velocity * delta  # Update the position using velocity

	# If bomb moves off screen, remove it
	if position.y > get_viewport().size.y:
		queue_free()

func _on_bomb_rigid_body_2d_body_entered(body: Node):
	if body.name == "Player":
		body.die()  # Trigger player's death or whatever behavior you want
		queue_free()  # Destroy the bomb after it interacts with the player
