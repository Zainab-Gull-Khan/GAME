extends Node2D

@export var crate_scene := preload("res://canabalt-assets-main/scenes/crates.tscn")  # Reference to the crate scene
@export var spawn_interval: float = 3.0  # Interval for spawning crates

var timer: Timer  # Timer instance declaration
var screen_width: float
var ground_y_position: float = 400.0  # Example Y position for the ground

func _ready():
	screen_width = get_viewport().get_visible_rect().size.x

	# Initialize and configure the timer
	timer = Timer.new()  # Create the timer instance
	timer.wait_time = spawn_interval
	timer.one_shot = false
	timer.autostart = true
	add_child(timer)  # Add the timer to the scene
	timer.connect("timeout", Callable(self, "_on_timer_timeout"))

	# Debugging output to check if timer is active
	print("Timer initialized, ready to spawn crates.")

func spawn_crate():
	if crate_scene:  # Check if crate_scene is valid
		var crate_instance = crate_scene.instantiate()  # Instantiate the crate scene

		# Randomize X position within the screen width
		var spawn_x = randf_range(100, screen_width - 100)  # Position it randomly within the screen
		var spawn_y = ground_y_position  # Set Y position to the ground level

		crate_instance.position = Vector2(spawn_x, spawn_y)  # Set the crate's position

		# Add the crate to the current scene
		get_tree().current_scene.add_child(crate_instance)

		# Debugging output to check if crate is spawning
		print("Crate spawned at position: ", crate_instance.position)
	else:
		print("Error: crate_scene is invalid or not loaded properly.")

func _on_timer_timeout() -> void:
	spawn_crate()  # Spawn the crate when the timer times out
	# Debugging output to check if timer timeout is working
	print("Timer timeout occurred, spawning crate.")
