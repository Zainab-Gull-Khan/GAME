extends Node2D

@export var spawn_positions := [Vector2(100, 400), Vector2(300, 400), Vector2(500, 400)]  # Positions for crates

# Called when the scene is ready
func _ready():
	# Find all crates in the scene and set their positions
	var crates = get_children()  # Get all child nodes of this Node2D (assumed to be crates)

	# Check that the number of crates matches the number of positions
	if crates.size() == spawn_positions.size():
		for i in range(crates.size()):
			crates[i].position = spawn_positions[i]  # Move the crate to the predefined position
	else:
		print("Warning: The number of crates doesn't match the number of spawn positions.")
