extends Control
@onready var label = $CountDownLabel
@onready var timer = $CountDownTimer
@onready var sound = $CountdownSound
@onready var game_start = $GameStartAudio

var count = 3		#countdown starting value
func _ready():
	label.text=str(count)	#initial countdown number
	sound.play()
	animate_text()
	timer.start()		#starting the timer

func animate_text():
	var tween = get_tree().create_tween()
	tween.tween_property(label, "scale", Vector2(1.5, 1.5), 0.2).set_trans(Tween.TRANS_BOUNCE)
	tween.tween_property(label, "scale", Vector2(1, 1), 0.2)

func _on_count_down_timer_timeout() -> void:
	count -= 1
	if count > 0:
		label.text = str(count)
		sound.play()
		animate_text()
		timer.start()
	else:
		Global.play_game_start()  # Play start sound globally
		await get_tree().create_timer(0.1).timeout  # Small delay to let audio start
		get_tree().change_scene_to_file("res://scenes/main_game_level2.tscn")  # Change scene immediately

		
