extends Node2D

func _on_level_1_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/level1_ready.tscn")

func _on_level_2_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/level2_ready.tscn")

func _on_texture_button_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
