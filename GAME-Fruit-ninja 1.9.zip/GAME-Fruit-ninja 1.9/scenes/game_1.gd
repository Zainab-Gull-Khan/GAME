extends Node2D

# Constants for game configuration
const MIN_SPAWN_X = 50
const MAX_SPAWN_X = 350
const SPAWN_Y = 700

const INITIAL_Y_VELOCITY = -900
const INITIAL_X_VELOCITY_RANGE = Vector2(-10, 10)

var Fruit = preload("res://scenes/fruit_1.tscn")
const Globals = preload("res://scripts/global.gd")
var Bomb = preload("res://scenes/bomb_scene.tscn")

# Game state variables
var SPAWN_INTERVAL = 2.0 
var score = 0
var is_game_active = true
var time = 0.0
var time_left = 60
var bobbing_tween = null
var num_fruits = 1
var fruit_waves = [
	["apple", "apple", "apple"],
	["orange", "orange", "orange"],
	["banana", "banana", "banana"],
	["coconut", "coconut", "coconut"]
]
var wave_index = 0
var wave_interval = 10
var time_since_last_wave = 0.0

@onready var countdown_label = $countdown_Label
@onready var game_over_label = $GameOverLabel
@onready var countdown_timer = $countdown_Timer
@onready var ticking_sound = $TickingAudio
@onready var explosion_sound = preload("res://assets/sounds/medium-explosion-40472.mp3")


func _ready():
	Global.set_game_over_label($GameOverLabel)
	spawn_fruit()
	$SpawnTimer.wait_time = SPAWN_INTERVAL
	$SpawnTimer.start()

	countdown_label.text = str(time_left)
	countdown_timer.wait_time = 1.0
	countdown_timer.start()
	countdown_timer.timeout.connect(_on_countdown_timer_timeout)
	

func _process(delta):
	if is_game_active:
		time += delta
		update_background()
		if int(time) % 10 == 0:
			if time_since_last_wave >= wave_interval:
				time_since_last_wave = 0.0
				spawn_fruit_wave()
			increase_difficulty()
		update_timer_effects()

func update_background():
	if score >= 1000:
		$Sprite2D.texture = preload("res://assets/images/bg green.jpg")

func increase_difficulty():
	if SPAWN_INTERVAL > 0.5:
		SPAWN_INTERVAL -= 0.1
		$SpawnTimer.wait_time = SPAWN_INTERVAL

func spawn_fruit_wave():
	if not is_game_active:
		return

	var fruit_scene = preload("res://scenes/fruit_1.tscn")

	for fruit_name in ["apple", "banana", "orange", "coconut"]:
		var fruit = fruit_scene.instantiate()
		add_child(fruit)

		match fruit_name:
			"apple":
				fruit.fruit_type = Globals.FruitType.APPLE
				fruit.textures = Global.textures[Globals.FruitType.APPLE]["whole"]
			"banana":
				fruit.fruit_type = Globals.FruitType.BANANA
				fruit.textures = Global.textures[Globals.FruitType.BANANA]["whole"]
			"orange":
				fruit.fruit_type = Globals.FruitType.ORANGE
				fruit.textures = Global.textures[Globals.FruitType.ORANGE]["whole"]
			"coconut":
				fruit.fruit_type = Globals.FruitType.COCONUT
				fruit.textures = Global.textures[Globals.FruitType.COCONUT]["whole"]

		var spawn_x = randf_range(MIN_SPAWN_X, MAX_SPAWN_X)
		fruit.position = Vector2(spawn_x, SPAWN_Y)
		fruit.velocity = Vector2(randf_range(-100, 100), -400)
		fruit.fruit_sliced.connect(_on_fruit_sliced)

func _on_countdown_timer_timeout():
	if is_game_active:
		time_left -= 1
		countdown_label.text = str(time_left)

		if time_left < 10:
			ticking_sound.play()
			start_bobbing_effect()

func update_timer_effects():
	var color = Color(0.7, 1.0, 0.7)
	countdown_label.add_theme_color_override("font_color", color)

func start_bobbing_effect():
	if bobbing_tween:
		bobbing_tween.kill()
	
	bobbing_tween = get_tree().create_tween()
	var original_pos = countdown_label.position
	var bob_offset = Vector2(3, -3)

	bobbing_tween.tween_property(countdown_label, "position", original_pos + bob_offset, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.tween_property(countdown_label, "position", original_pos, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.set_loops()

func spawn_fruit():
	if not is_game_active:
		return
		
	for i in range(num_fruits):
		var entity
		if randf() < 0.8:
			entity = Fruit.instantiate()
			entity.fruit_sliced.connect(_on_fruit_sliced)
		else:
			entity = Bomb.instantiate()
			# Connect bomb sliced signal if available on your bomb scene
			entity.bomb_sliced.connect(_on_bomb_sliced)
		
		add_child(entity)
		entity.position = Vector2(randf_range(MIN_SPAWN_X, MAX_SPAWN_X), SPAWN_Y)
		entity.velocity = Vector2(
			randf_range(INITIAL_X_VELOCITY_RANGE.x, INITIAL_X_VELOCITY_RANGE.y),
			INITIAL_Y_VELOCITY
		)

		var tween = create_tween()
		tween.tween_property(entity, "scale", Vector2(1, 1), 0.3)\
			 .from(Vector2(0.1, 0.1))\
			 .set_trans(Tween.TRANS_BOUNCE)\
			 .set_ease(Tween.EASE_OUT)


func _on_spawn_timer_timeout():
	spawn_fruit()

func _on_fruit_sliced():
	score += 10
	$ScoreLabel.text = "Score: %d" % score
	score_popup(get_global_mouse_position())

func score_popup(pos: Vector2, text = "+10", color = Color(0.2, 0.2, 0.2)):
	var popup = Label.new()
	popup.text = text
	popup.add_theme_font_size_override("font_size", 32)
	popup.add_theme_color_override("font_color", color)
	popup.z_index = 1000

	add_child(popup)

	popup.global_position = pos
	popup.scale = Vector2(0.1, 0.1)
	popup.modulate.a = 1.0

	var tween = popup.create_tween()
	tween.tween_property(popup, "scale", Vector2(1.0, 1.0), 1)\
		.set_trans(Tween.TRANS_BOUNCE)\
		.set_ease(Tween.EASE_OUT)

	var target_pos = popup.global_position + Vector2(0, -30)
	tween.parallel().tween_property(popup, "global_position", target_pos, 0.5)\
		.set_trans(Tween.TRANS_SINE)

	tween.tween_property(popup, "modulate:a", 0.0, 0.4)\
		.set_trans(Tween.TRANS_SINE)

	tween.finished.connect(func(): popup.queue_free())

func _on_bomb_collision(viewport, event, shape_idx, entity) -> void:
	if event is InputEventMouseButton and event.pressed:
		print("bomb collision detected")
		entity.queue_free()
		_on_bomb_sliced()

func _on_bomb_sliced() -> void:
	#time_left -= 10
	#if time_left <= 1:
		#time_left = 0

	#countdown_label.text = "Time Left: %d" % time_left
	score_popup(get_global_mouse_position(), "game over", Color(1, 0, 0))
	_screen_shake()
	
	var explosion: Sprite2D = Sprite2D.new()
	explosion.texture = preload("res://assets/images/explosion_small.png")
	explosion.global_position = get_global_mouse_position()
	add_child(explosion)

	var tween = explosion.create_tween()
	tween.tween_property(explosion, "modulate:a", 0.0, 0.5)\
		 .set_trans(Tween.TRANS_LINEAR)
	tween.finished.connect(func(): explosion.queue_free())
	var audio_player = AudioStreamPlayer.new()
	audio_player.stream = explosion_sound
	add_child(audio_player)
	audio_player.play()
	audio_player.finished.connect(audio_player.queue_free)
	game_over()

func _screen_shake() -> void:
	var root = get_tree().get_current_scene()
	var shake_timer: float = 0.3
	var shake_intensity: float = 3.0
	var original_position: Vector2 = root.position

	while shake_timer > 0:
		var delta: float = get_process_delta_time()
		shake_timer -= delta

		var offset_x: float = randf_range(-shake_intensity, shake_intensity)
		var offset_y: float = randf_range(-shake_intensity, shake_intensity)

		root.position = original_position + Vector2(offset_x, offset_y)
		await get_tree().create_timer(0.05).timeout

	root.position = original_position
	
func game_over():
	is_game_active = false
	countdown_timer.stop()
	countdown_timer.stop()
	
	if bobbing_tween:
		bobbing_tween.kill()
		
	game_over_label.show()
	var tween = get_tree().create_tween()
	tween.tween_property(game_over_label, "modulate:a", 1.0, 0.5)\
		 .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(game_over_label, "scale", Vector2(1.2, 1.2), 0.5)\
		 .from(Vector2(0.8, 0.8))\
		 .set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		 
	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")
