extends Sprite2D

@onready var audio_player = $hourglassAudio

func _ready():
	# Preload the audio
	audio_player.stream = preload("res://assets/sounds/tick-tock-104746.mp3")

func _on_area_2d_mouse_entered() -> void:
	audio_player.play()

func _on_area_2d_mouse_exited() -> void:
	audio_player.stop()
