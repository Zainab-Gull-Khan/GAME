extends Label

@onready var bounce_sound = $"../mainAudio"

func _ready():
	var final_pos = position
	var screen_height = get_viewport_rect().size.y
	position = Vector2(final_pos.x, screen_height + 100)
	modulate.a = 0.0

	var tween = get_tree().create_tween()

	# Play sound as soon as label starts jumping up
	bounce_sound.play()

	# Fade in and move up past final position in parallel
	tween.tween_property(self, "modulate:a", 1.0, 0.4).set_trans(Tween.TRANS_LINEAR).set_ease(Tween.EASE_IN)
	tween.parallel().tween_property(self, "position", final_pos - Vector2(0, 30), 0.4)\
		.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

	# Bounce down into place
	tween.tween_property(self, "position", final_pos, 0.3)\
		.set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
