extends Sprite2D
@onready var bolt = $boltAudio

func _ready():
	bolt.stream = preload("res://assets/sounds/thunder-307513.mp3")

func _on_mouse_entered() -> void:
	bolt.play()
	
func _on_mouse_exited() -> void:
	bolt.stop()
