extends CharacterBody2D

# Constants for movement and jump
const GRAVITY = 500.0
const MAX_JUMP_SPEED = -500.0  # Maximum jump speed
const MIN_JUMP_SPEED = -250.0  # Minimum jump speed
const MOVE_SPEED = 100.0

# Declare a reference to the AnimationSprite2D to handle animations
@onready var anim_sprite = $AnimatedSprite2D  # Change this if your AnimationSprite2D has a different name

var jump_time = 0.0  # Time the spacebar is held down
var max_jump_duration = 0.3  # Maximum time for holding spacebar for jump (in seconds)

func _physics_process(delta):
	# Apply gravity
	velocity.y += GRAVITY * delta

	# Left / right movement
	if Input.is_action_pressed("ui_right"):
		velocity.x = MOVE_SPEED
		anim_sprite.flip_h = false  # Make the sprite face right
	elif Input.is_action_pressed("ui_left"):
		velocity.x = -MOVE_SPEED
		anim_sprite.flip_h = true  # Make the sprite face left
	else:
		velocity.x = 0

	# Jumping
	if is_on_floor():
		if Input.is_action_just_pressed("ui_accept"):  # Start the jump when space is first pressed
			jump_time = 0.0  # Reset jump time
			velocity.y = MAX_JUMP_SPEED
			anim_sprite.play("jump")  # Play jump animation
		elif Input.is_action_pressed("ui_accept"):  # While holding spacebar
			jump_time += delta
			# Gradually increase the jump strength the longer the spacebar is held
			velocity.y = lerp(MAX_JUMP_SPEED, MIN_JUMP_SPEED, jump_time / max_jump_duration)
		elif Input.is_action_just_released("ui_accept"):  # Stop the jump when space is released
			jump_time = 0.0

	# If the player is falling
	elif velocity.y < 0:
		anim_sprite.play("jumping")  # Play jump animation when falling
	else:
		anim_sprite.play("running")  # Play fall animation

	# Play animations based on state
	if velocity.x != 0:
		anim_sprite.play("running")  # Play run animation when moving
	else:
		anim_sprite.play("idle")  # Play idle animation when not moving

	# Move the sprite
	move_and_slide()
