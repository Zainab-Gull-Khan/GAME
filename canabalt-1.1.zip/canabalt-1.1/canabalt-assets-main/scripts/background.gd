extends ParallaxBackground
@export var scroll_speed = Vector2(500,0)

func _process(delta):
	scroll_offset-=scroll_speed*delta
