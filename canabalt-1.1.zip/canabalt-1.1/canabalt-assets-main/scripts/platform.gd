extends Node2D

# Texture Constants
const ROOF_TEXTURE := preload("res://canabalt-assets-main/images/roof1.png")
const ROOF_TEXTURE_END := preload("res://canabalt-assets-main/images/roof4.png")
const WALL_TEXTURES := [
	preload("res://canabalt-assets-main/images/wall1.png"),
	preload("res://canabalt-assets-main/images/wall2.png"),
	preload("res://canabalt-assets-main/images/wall3.png"),
	preload("res://canabalt-assets-main/images/wall4.png")
]
const WINDOW_TEXTURE := preload("res://canabalt-assets-main/images/window1.png")

# Building Configuration
const SEGMENT_WIDTH := 48
const SEGMENT_HEIGHT := 16
@export var height_segments := 10
@export var window_interval := 2
@export var move_speed := 500.0

# Wrapping Variables
var screen_size : Vector2
var building_width : float
var wrap_offset : float = 0.0
var building_parts : Array = []

func _ready():
	randomize()
	screen_size = get_viewport().get_visible_rect().size
	generate_building()
	building_width = (ceil(screen_size.x / SEGMENT_WIDTH) + 2) * SEGMENT_WIDTH
	position = Vector2(-SEGMENT_WIDTH * 2, 0)

func _process(delta):
	for part in building_parts:
		part.position.x -= move_speed * delta
		if part.position.x < -SEGMENT_WIDTH:
			part.position.x += building_width + SEGMENT_WIDTH

func generate_building():
	# Clear previous building
	for child in get_children():
		child.queue_free()
	building_parts.clear()

	var segment_count = ceil(screen_size.x / SEGMENT_WIDTH) + 4
	var base_y = screen_size.y

	for y in range(height_segments):
		var is_window_row = (y % window_interval == 0) and (y != height_segments - 1)

		for x in range(segment_count):
			# Create StaticBody2D for collision-enabled segment
			var platform_segment = StaticBody2D.new()
			add_child(platform_segment)
			building_parts.append(platform_segment)

			# Sprite2D as a child of StaticBody2D
			var sprite = Sprite2D.new()
			sprite.position = Vector2.ZERO
			if y == height_segments - 1:
				sprite.texture = ROOF_TEXTURE_END if (x == 0 or x == segment_count - 1) else ROOF_TEXTURE
			elif is_window_row:
				sprite.texture = WINDOW_TEXTURE
			else:
				sprite.texture = WALL_TEXTURES[randi() % WALL_TEXTURES.size()]
			platform_segment.add_child(sprite)

			# Add CollisionShape2D ONLY for the top row (roof)
			if y == height_segments - 1:
				var collision = CollisionShape2D.new()
				var shape = RectangleShape2D.new()
				shape.size = Vector2(SEGMENT_WIDTH, SEGMENT_HEIGHT)
				collision.shape = shape
				collision.position = Vector2(SEGMENT_WIDTH / 2, SEGMENT_HEIGHT / 2)
				platform_segment.add_child(collision)

			# Position the whole body
			platform_segment.position = Vector2(x * SEGMENT_WIDTH, base_y - (y * SEGMENT_HEIGHT))
