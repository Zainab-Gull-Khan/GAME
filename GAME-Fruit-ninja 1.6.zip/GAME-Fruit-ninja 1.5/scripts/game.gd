extends Node2D 

# Constants for game configuration
const MIN_SPAWN_X = 50
const MAX_SPAWN_X = 350
const SPAWN_Y = 700

const INITIAL_Y_VELOCITY = -900
const INITIAL_X_VELOCITY_RANGE = Vector2(-10, 10)

var Fruit = preload("res://scenes/fruit.tscn")
var Bomb = preload("res://scenes/bomb_scene.tscn")  # Don't instantiate globally

# Game state variables
var SPAWN_INTERVAL = 2.0 
var score = 0
var is_game_active = true
var time = 0.0
var time_left = 30
var bobbing_tween = null  
var num_fruits = 1
var is_combo_active = false
var combo_timeout = false
var combo_triggered = false

@onready var countdown_label = $countdown_Label
@onready var countdown_timer = $countdown_Timer
@onready var ticking_sound = $TickingAudio
@onready var spawn_timer = $SpawnTimer
@onready var game_over_label = $GameOverLabel
@onready var score_label = $ScoreLabel
@onready var explosion_sound = preload("res://assets/sounds/medium-explosion-40472.mp3")
@onready var combo_label = $ComboLabel
@onready var combo_bar = $ComboProgressBar
@onready var combo1x = $combo1xAudio
@onready var combo_timer = $ComboTimer

func _ready():
	game_over_label.hide()
	spawn_timer.wait_time = SPAWN_INTERVAL
	spawn_timer.start()

	# Initialize countdown timer
	countdown_label.text = str(time_left)
	countdown_timer.wait_time = 1.0
	countdown_timer.start()
	countdown_timer.timeout.connect(_on_countdown_timer_timeout)
	call_deferred("_init_nodes")
	
func _init_nodes():
	
	if countdown_label:
		countdown_label.text = str(time_left)
	if countdown_timer and is_instance_valid(countdown_timer):
		countdown_timer.wait_time = 1.0
		countdown_timer.start()
		countdown_timer.timeout.connect(_on_countdown_timer_timeout)
	if combo_label:
		combo_label.text =  "combo!"
	if combo_timer:
		print("Combo timer found and working!")
		combo_timer.timeout.connect(_on_combo_timer_timeout)
	if combo1x:
		combo1x.play()
	if combo_bar:
		combo_bar.visible = false
	else:
		print("Combo timer not found")
func _process(delta):
	if is_game_active:
		time += delta
		for i in range(time):
			if int(time) % 15 == 0:
				increase_difficulty()
		update_timer_effects()

func increase_difficulty():
	if SPAWN_INTERVAL > 0.3:  
		SPAWN_INTERVAL -= 0.5
		spawn_timer.wait_time = SPAWN_INTERVAL

func _on_countdown_timer_timeout():
	if time_left > 0:
		time_left -= 1
		countdown_label.text = str(time_left)

		if time_left <= 10:
			ticking_sound.play()
			start_bobbing_effect()

	if time_left == 0:
		game_over()

func update_timer_effects():
	var color = Color(0, 1, 0)  

	if time_left <= 10:
		color = Color(1, 0, 0)  

	countdown_label.add_theme_color_override("font_color", color)

func start_bobbing_effect():
	if bobbing_tween:
		bobbing_tween.kill()  

	bobbing_tween = get_tree().create_tween()
	var original_pos = countdown_label.position
	var bob_offset = Vector2(3, -3)  

	bobbing_tween.tween_property(countdown_label, "position", original_pos + bob_offset, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.tween_property(countdown_label, "position", original_pos, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.set_loops()

func game_over():
	is_game_active = false
	spawn_timer.stop()
	countdown_timer.stop()

	if bobbing_tween:
		bobbing_tween.kill()

	game_over_label.show()  

	var tween = get_tree().create_tween()
	tween.tween_property(game_over_label, "modulate:a", 1.0, 0.5)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	tween.parallel().tween_property(game_over_label, "scale", Vector2(1.2, 1.2), 0.5)\
		.from(Vector2(0.8, 0.8))\
		.set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)

	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")

func spawn_fruit():
	if not is_game_active:
		return
	
	for i in range(num_fruits):
		var entity
		if randf() < 0.8:
			entity = Fruit.instantiate()
			entity.fruit_sliced.connect(_on_fruit_sliced)
		else:
			entity = Bomb.instantiate()
			entity.bomb_sliced.connect(_on_bomb_sliced)

		add_child(entity)
		entity.position = Vector2(randf_range(MIN_SPAWN_X, MAX_SPAWN_X), SPAWN_Y)
		entity.velocity = Vector2(randf_range(INITIAL_X_VELOCITY_RANGE.x, INITIAL_X_VELOCITY_RANGE.y),
			INITIAL_Y_VELOCITY)

		var tween = create_tween()
		tween.tween_property(entity, "scale", Vector2(1, 1), 0.3)\
			.from(Vector2(0.1, 0.1))\
			.set_trans(Tween.TRANS_BOUNCE)\
			.set_ease(Tween.EASE_OUT)

func _on_spawn_timer_timeout():
	spawn_fruit()

func _on_fruit_sliced():
	var points = 10
	if is_combo_active:
		points *= 2  # Double the score during combo mode

	score += points
	score_label.text = "Score: %d" % score
	score_popup(get_global_mouse_position(), "+%d" % points, Color(0.2, 0.2, 0.2))

	if not is_combo_active and score % 100 == 0 and not combo_triggered:
		start_combo()

	if is_combo_active:
		if combo_timeout:
			end_combo()
		else:
			combo_bar.value += 10
			if combo_bar.value >= 100:
				end_combo()

				
func show_combo_popup():
	if combo_label:
		combo_label.text = "COMBO!"
		combo_label.visible = true
		combo_label.scale = Vector2(0.5, 0.5)
		combo_label.modulate.a = 1.0

		var tween = create_tween()
		tween.tween_property(combo_label, "scale", Vector2(1.2, 1.2), 0.3)\
			.set_trans(Tween.TRANS_BOUNCE)\
			.set_ease(Tween.EASE_OUT)

		tween.tween_property(combo_label, "position", combo_label.position + Vector2(0, -30), 0.5)\
			.set_delay(0.5)\
			.set_trans(Tween.TRANS_SINE)

		tween.finished.connect(func(): 
			if not is_combo_active:  # Only hide if the combo is not active anymore
				combo_label.visible = false)
				
func start_combo():
	is_combo_active = true
	combo_timeout = false
	combo_label.text = "COMBO!"
	combo_label.visible = true
	combo_label.scale = Vector2(0.5, 0.5)
	combo_label.modulate.a = 1.0
	combo_bar.visible = true
	combo_bar.value = 0

	if combo1x and not combo1x.playing:
		combo1x.play()
	if combo_timer:
		combo_timer.start()

	var tween = create_tween()
	tween.tween_property(combo_label, "scale", Vector2(1.2, 1.2), 0.3)\
		.set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)

	tween.tween_property(combo_label, "position", combo_label.position + Vector2(0, -30), 0.5)\
		.set_delay(0.5).set_trans(Tween.TRANS_SINE)

	tween.finished.connect(func(): 
		if not is_combo_active:
			combo_label.visible = false)
			
func end_combo():
	if not is_combo_active:
		return

	is_combo_active = false
	combo_timeout = false
	combo_bar.visible = false
	combo_bar.value = 0
	combo_label.visible = false
	combo_timer.stop()

	var tween = create_tween()
	tween.tween_property(combo_label, "modulate:a", 0.0, 0.5).set_trans(Tween.TRANS_SINE)
	tween.tween_property(combo_label, "position", combo_label.position + Vector2(0, -30), 0.5).set_trans(Tween.TRANS_SINE)

	tween.finished.connect(func(): combo_label.visible = false)

	# Optional sound here, but don’t spam
	var audio_player = AudioStreamPlayer.new()
	audio_player.stream = explosion_sound
	add_child(audio_player)
	audio_player.play()
	audio_player.finished.connect(audio_player.queue_free)

func _on_combo_timer_timeout() -> void:
	combo_timeout = true	#setting the timeout flag
	
func _on_bomb_collision(viewport, event, shape_idx, entity):
	if event is InputEventMouseButton and event.pressed:
		print("bomb collision detected")
		entity.queue_free()  
		_on_bomb_sliced()     

func _on_bomb_sliced():
	# Reduce the remaining time when the bomb is sliced
	time_left -= 10
	if time_left <= 1:
		time_left = 0  # Ensure the time doesn't go negative
	
	# Update the countdown label to reflect the new time
	countdown_label.text = "Time Left: %d" % time_left
	
	# Popup message to show the deduction
	score_popup(get_global_mouse_position(), "-10 sec", Color(1, 0, 0))
	_screen_shake()
	# Create explosion effect for the bomb
	var explosion = Sprite2D.new()

	explosion.texture = preload("res://assets/images/explosion_small.png")  
	explosion.global_position = get_global_mouse_position()
	add_child(explosion)

	var tween = explosion.create_tween()
	tween.tween_property(explosion, "modulate:a", 0.0, 0.5).set_trans(Tween.TRANS_LINEAR)
	tween.finished.connect(func():
		explosion.queue_free())
	
	if is_combo_active:
		end_combo()
		
	
func score_popup(pos: Vector2, text="+10", color=Color(0.2, 0.2, 0.2)):
	var popup = Label.new()
	popup.text = text
	popup.add_theme_font_size_override("font_size", 32)
	popup.add_theme_color_override("font_color", color)  
	popup.z_index = 1000

	add_child(popup)

	popup.global_position = pos
	popup.scale = Vector2(0.1, 0.1)
	popup.modulate.a = 1.0

	var tween = popup.create_tween()
	tween.tween_property(popup, "scale", Vector2(1.0, 1.0), 1)\
		.set_trans(Tween.TRANS_BOUNCE)\
		.set_ease(Tween.EASE_OUT)

	var target_pos = popup.global_position + Vector2(0, -30)
	tween.parallel().tween_property(popup, "global_position", target_pos, 0.5)\
		.set_trans(Tween.TRANS_SINE)

	tween.tween_property(popup, "modulate:a", 0.0, 0.4)\
		.set_trans(Tween.TRANS_SINE)

	tween.finished.connect(func(): popup.queue_free()) 
#shaking the screen code 

func _screen_shake():
	# Apply shake to the root node
	var root = get_tree().get_current_scene()  # Get the current active scene's root node
	var shake_timer = 0.3  # Shake duration
	var shake_intensity = 5.0  # Maximum shake offset

	while shake_timer > 0:
		shake_timer -= get_process_delta_time()
		
		# Generate random offsets
		var offset_x = randf_range(-shake_intensity, shake_intensity)
		var offset_y = randf_range(-shake_intensity, shake_intensity)
		
		# Apply the offset temporarily
		root.position += Vector2(offset_x, offset_y)
		
		# Wait briefly before the next shake
		await get_tree().create_timer(0.05).timeout

	# Reset the root node position after shaking
	root.position = Vector2.ZERO 
