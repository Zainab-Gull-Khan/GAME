extends Node2D

# Constants for game configuration
const MIN_SPAWN_X = 50
const MAX_SPAWN_X = 350
const SPAWN_Y = 700

const INITIAL_Y_VELOCITY = -900
const INITIAL_X_VELOCITY_RANGE = Vector2(-10, 10)

var Fruit = preload("res://scenes/fruit_1.tscn")
const Globals = preload("res://scripts/global.gd")
#const ComboNode2D = preload("res://scenes/ComboNode2D.tscn")

# Game state variables
var Bomb = preload("res://scenes/bomb_scene.tscn") 
var SPAWN_INTERVAL = 2.0 
var score = 0
var is_game_active = true
var time = 0.0
var time_left = 30
var bobbing_tween = null  # Tween for bobbing effect
var num_fruits= 1
var fruit_waves = [
	["apple", "apple", "apple"],
	["orange", "orange", "orange"],
	["banana", "banana", "banana"],
	["coconut", "coconut", "coconut"]
]
var wave_index = 0
var wave_interval = 10  # Time (in seconds) between waves
var time_since_last_wave = 0.0

var combo_level = 1
var combo_timer = Timer.new()
var combo_active = false
var combo_reset_time = 0.4  # Timeout for combo reset
var combo_node: Node2D  # Reference to ComboNode2D
var combo_timer_active = false


@onready var countdown_label = $countdown_Label
@onready var countdown_timer = $countdown_Timer
@onready var ticking_sound = $TickingAudio
@onready var score_label = $ScoreLabel
@onready var spawn_timer = $SpawnTimer
@onready var game_over_label = $GameOverLabel

func _ready():
	combo_timer.timeout.connect(_on_combo_timer_timeout)
	Global.set_game_over_label($GameOverLabel)	#to ensure game over label is hidden at the beginning of them game
	spawn_fruit()
	$SpawnTimer.wait_time = SPAWN_INTERVAL
	$SpawnTimer.start()

	# Initialize countdown timer
	countdown_label.text = str(time_left)
	countdown_timer.wait_time = 1.0
	countdown_timer.start()
	countdown_timer.timeout.connect(_on_countdown_timer_timeout)
	#for combo functionality
	combo_node = $ComboNode2D
	combo_timer = Timer.new()
	combo_timer.wait_time = 0.4  # Adjust combo reset time
	combo_timer.one_shot = true
	combo_timer.connect("timeout", Callable(self, "_reset_combo"))
	add_child(combo_timer)

func _process(delta):
	if is_game_active:
		time += delta
		update_background()
		for i in range(time):
			if int(time)%5 == 0:
				if time_since_last_wave >= wave_interval:
					time_since_last_wave = 0.0
					spawn_fruit_wave()
				increase_difficulty()
		update_timer_effects()
		
func update_background():
	if score >= 200:
		$Sprite2D.texture = preload("res://assets/images/bg green.jpg")
		
func increase_difficulty():
	if SPAWN_INTERVAL > 0.5:  # Prevent spawn interval from getting too fast
		SPAWN_INTERVAL -= 0.1
		$SpawnTimer.wait_time = SPAWN_INTERVAL
##trying to figure out the bnus part

func spawn_fruit_wave():
	if not is_game_active:
		return
	# Preload fruit scene once
	var fruit_scene = preload("res://scenes/fruit_1.tscn")
	for fruit_name in ["apple", "banana", "orange", "coconut"]:
		var fruit = fruit_scene.instantiate()
		add_child(fruit)
		var textures= Global.textures
		# Hard-code fruit types directly using the global script
		match fruit_name:
			"apple":
				fruit.fruit_type = Global.FruitType.APPLE
				fruit.textures = Global.textures[Global.FruitType.APPLE]["whole"]
			"banana":
				fruit.fruit_type = Global.FruitType.BANANA
				fruit.textures = Global.textures[Global.FruitType.BANANA]["whole"]
			"orange":
				fruit.fruit_type = Global.FruitType.ORANGE
				fruit.textures = Global.textures[Global.FruitType.ORANGE]["whole"]
			"coconut":
				fruit.fruit_type = Global.FruitType.COCONUT
				fruit.textures = Global.textures[Global.FruitType.COCONUT]["whole"]

		# Set position and velocity
		var spawn_x = randf_range(MIN_SPAWN_X, MAX_SPAWN_X)
		fruit.position = Vector2(spawn_x, SPAWN_Y)
		fruit.velocity = Vector2(randf_range(-100, 100), -400)
		fruit.fruit_sliced.connect(_on_fruit_sliced)

func _on_countdown_timer_timeout():
	if time_left > 0:
		time_left -= 1
		countdown_label.text = str(time_left)
		
		# Play ticking sound and start bobbing effect in last 10 seconds
		if time_left <= 10:
			ticking_sound.play()
			start_bobbing_effect()

	if time_left == 0:
		game_over()

func update_timer_effects():
	var color = Color(0.7, 1.0, 0.7)  

	if time_left <= 10:
		color = Color(1, 0, 0)  # Red
#
	# Update font fill color directly
	countdown_label.add_theme_color_override("font_color", color)

func start_bobbing_effect():
	if bobbing_tween:
		bobbing_tween.kill()  # Stop any previous tween
	
	bobbing_tween = get_tree().create_tween()
	var original_pos = countdown_label.position
	var bob_offset = Vector2(3, -3)  # Moves 3 pixels up and down

	bobbing_tween.tween_property(countdown_label, "position", original_pos + bob_offset, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.tween_property(countdown_label, "position", original_pos, 0.3)\
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.set_loops()  # Keep looping until stopped

func game_over():
	is_game_active = false
	$SpawnTimer.stop()
	countdown_timer.stop()

	if bobbing_tween:
		bobbing_tween.kill()  # Stop bobbing effect on game over

	var game_over_label = $GameOverLabel
	game_over_label.show()  # Make it visible

	# Create Tween for fade-in and scale-up effect
	var tween = get_tree().create_tween()
	tween.tween_property(game_over_label, "modulate:a", 1.0, 0.5) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	tween.parallel().tween_property(game_over_label, "scale", Vector2(1.2, 1.2), 0.5) \
		.from(Vector2(0.8, 0.8)) \
		.set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)

	# Wait 1.5 seconds before switching to the game-over scene
	await get_tree().create_timer(1.0).timeout
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")

func spawn_fruit():
	if not is_game_active:
		return
	
	for i in range(num_fruits):
		var entity
		if randf() < 0.8:
			entity = Fruit.instantiate()
			entity.fruit_sliced.connect(_on_fruit_sliced)
		else:
			entity = Bomb.instantiate()
			entity.bomb_sliced.connect(_on_bomb_sliced)

		add_child(entity)
		entity.position = Vector2(randf_range(MIN_SPAWN_X, MAX_SPAWN_X), SPAWN_Y)
		entity.velocity = Vector2(randf_range(INITIAL_X_VELOCITY_RANGE.x, INITIAL_X_VELOCITY_RANGE.y),
			INITIAL_Y_VELOCITY)

		var tween = create_tween()
		tween.tween_property(entity, "scale", Vector2(1, 1), 0.3)\
			.from(Vector2(0.1, 0.1))\
			.set_trans(Tween.TRANS_BOUNCE)\
			.set_ease(Tween.EASE_OUT)

func _on_spawn_timer_timeout():
	spawn_fruit()

func _on_fruit_sliced():
	# Increase score with combo multiplier
	var added_score = 10 * combo_level
	score += added_score
	score_label.text = "Score: %d" % score
	
	# Show popup for added score
	score_popup(get_global_mouse_position(), "+%d" % added_score, Color(3, 5, 67))
	
	# Update combo level
	combo_level += 1
	combo_active = true

	# Restart the timer (prevents combo loss if slicing continues)
	combo_timer.start()

	# Update combo UI
	_update_combo_display()

func _update_combo_display():
	if $combo_label:
		if combo_level > 1:
			$combo_label.text = "Combo x%d!" % combo_level
			_animate_combo_text()
		else:
			$combo_label.text = ""
	
func reset_combo():
	combo_level = 1
	combo_active = false
	combo_node.hide_combo()
	combo_timer_active = false

func _animate_combo_text():
	if not $combo_label:
		return

	var tween = $combo_label.create_tween()
	tween.tween_property($combo_label, "scale", Vector2(1.5, 1.5), 0.2).set_trans(Tween.TRANS_BOUNCE)
	tween.tween_property($combo_label, "scale", Vector2(1.0, 1.0), 0.2).set_trans(Tween.TRANS_LINEAR)
	tween.tween_property($combo_label, "modulate:a", 1.0, 0.2)

func _on_bomb_collision(viewport, event, shape_idx, entity):
	if event is InputEventMouseButton and event.pressed:
		print("bomb collision detected")
		entity.queue_free()  
		_on_bomb_sliced()    

func _on_bomb_sliced():
	# Create explosion effect for the bomb
	var explosion = Sprite2D.new()
	explosion.texture = preload("res://assets/images/explosion_small.png")  
	explosion.global_position = get_global_mouse_position()
	add_child(explosion)

	# Play explosion animation
	var tween = explosion.create_tween()
	tween.tween_property(explosion, "modulate:a", 0.0, 0.7).set_trans(Tween.TRANS_LINEAR)
	tween.finished.connect(func(): explosion.queue_free())

	# Play explosion sound
	_play_explosion_sound()
	_screen_shake()
	# End the game by transitioning to the Game Over scene
	await get_tree().create_timer(0.5).timeout  # Add a short delay for visual/audio effect
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")
	
func _play_explosion_sound():
	var audio_player = AudioStreamPlayer.new()
	audio_player.stream = preload("res://assets/sounds/medium-explosion-40472.mp3")  # Replace with your sound file path
	add_child(audio_player)
	audio_player.play()
	audio_player.connect("finished", audio_player.queue_free)  # Remove the player after the sound finishes

func score_popup(pos: Vector2, text="+10", color=Color(0.2, 0.2, 0.2)):
	var popup = Label.new()
	popup.text = text
	popup.add_theme_font_size_override("font_size", 32)
	popup.add_theme_color_override("font_color", color)  
	popup.z_index = 1000

	add_child(popup)

	popup.global_position = pos
	popup.scale = Vector2(0.1, 0.1)
	popup.modulate.a = 1.0

	var tween = popup.create_tween()
	tween.tween_property(popup, "scale", Vector2(1.0, 1.0), 1)\
		.set_trans(Tween.TRANS_BOUNCE)\
		.set_ease(Tween.EASE_OUT)

	var target_pos = popup.global_position + Vector2(0, -30)
	tween.parallel().tween_property(popup, "global_position", target_pos, 0.5)\
		.set_trans(Tween.TRANS_SINE)

	tween.tween_property(popup, "modulate:a", 0.0, 0.4)\
		.set_trans(Tween.TRANS_SINE)

	tween.finished.connect(func(): popup.queue_free()) 
	 
func _screen_shake():
	# Apply shake to the root node
	var root = get_tree().get_current_scene()  # Get the current active scene's root node
	var shake_timer = 0.3  # Shake duration
	var shake_intensity = 5.0  # Maximum shake offset

	while shake_timer > 0:
		shake_timer -= get_process_delta_time()
		
		# Generate random offsets
		var offset_x = randf_range(-shake_intensity, shake_intensity)
		var offset_y = randf_range(-shake_intensity, shake_intensity)
		
		# Apply the offset temporarily
		root.position += Vector2(offset_x, offset_y)
		
		# Wait briefly before the next shake
		await get_tree().create_timer(0.05).timeout

	# Reset the root node position after shaking
	root.position = Vector2.ZERO 
	
func _on_combo_fruit_sliced():
	if not combo_timer_active:	# If the combo timer isn't active, start it
		combo_timer.start(combo_reset_time)
		combo_timer_active = true

	# Increase the combo level with each successful slice
	combo_level += 1
	combo_node.show_combo(combo_level) # Show combo effects
	var added_score = 10 * combo_level
	score += added_score
	score_label.text = "Score: %d" % score

	# Play combo sound based on the combo level
	combo_node.play_combo_sound()

	# Restart the combo timer (prevents combo loss if slicing continues)
	combo_timer.start(combo_reset_time)
	combo_node.update_combo_meter()

func _on_combo_bomb_sliced():
	reset_combo()

func _on_combo_timer_timeout():
	if combo_timer_active:
		reset_combo()
		_update_combo_display()

func update_background_color():
	var color = Color(1, 1 - combo_level * 0.2, 1 - combo_level * 0.2)
	$BackgroundColor.modulate = color  # Assuming BackgroundColor is your background node
# This method can be used to update combo text on the screen
func update_combo_text():
	# Update the UI or combo display (this is just an example)
	update_combo_text().text = "Combo: %d" % combo_level
