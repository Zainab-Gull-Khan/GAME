extends Node2D
signal combo_changed(combo_level)

var combo_level = 1
var combo_timer := Timer.new()
var combo_timeout := 0.4
var combo_count = 0
var is_combo_active = false
var score_multiplier = 1

@onready var combo_label = $Label  # Reference the Label node
@onready var sound_1x = $combo1  # Reference combo1 sound player
@onready var sound_2x = $combo2  # Reference combo2 sound player
@onready var sound_3x = $combo3  # Reference combo3 sound player
@onready var background = $"../Background"  # Reference the background
@onready var combo_meter = $ComboMeter

func _ready():
	combo_timer.set_wait_time(combo_timeout)
	#combo_timer.timeout.connect(_on_combo_timer_timeout)
	add_child(combo_timer)

func on_fruit_sliced(position: Vector2):
	if not is_combo_active:
		is_combo_active = true
		combo_level = 1
		combo_count = 1
		score_multiplier = 1
	else:
		combo_level += 1
		combo_count += 1
		score_multiplier = combo_level

	emit_signal("combo_changed", combo_level)
	_play_combo_sound()
	_show_combo_text(position)
	_update_background_color()
	_update_combo_meter()

	combo_timer.start()

func on_bomb_hit():
	_reset_combo()

#func _on_combo_timeout():
	#_reset_combo()

func _reset_combo():
	combo_level = 1
	combo_count = 0
	score_multiplier = 1
	is_combo_active = false
	emit_signal("combo_changed", combo_level)
	_update_background_color()
	_update_combo_meter()

func _play_combo_sound():
	var sound = AudioStreamPlayer.new()
	if combo_level >= 3:
		sound.stream = sound_3x.stream
	elif combo_level == 2:
		sound.stream = sound_2x.stream
	else:
		sound.stream = sound_1x.stream
	add_child(sound)
	sound.play()
	sound.finished.connect(sound.queue_free)

func _show_combo_text(position: Vector2):
	combo_label.text = "x" + str(combo_level)  # Update combo text with current combo level
	combo_label.position = position  # Position the label at the desired location
	get_tree().current_scene.add_child(combo_label)

func _update_background_color():
	var colors = {
		1: Color.ANTIQUE_WHITE,
		2: Color.YELLOW_GREEN,
		3: Color.ORANGE_RED,
		4: Color.DARK_RED
	}
	background.color = colors.get(combo_level, Color.DARK_RED)

func _update_combo_meter():
	if combo_meter:
		# Update the progress bar value based on the combo level
		combo_meter.value = clamp(combo_level * 20, 0, 100)
