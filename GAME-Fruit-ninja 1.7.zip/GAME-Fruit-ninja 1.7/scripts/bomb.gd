extends Sprite2D
@onready var explosion_texture = preload("res://assets/images/explosion_small.png")

var velocity = Vector2.ZERO
var gravity = 800.0
var rotation_speed = 0.0

signal bomb_sliced  # Signal emitted when bomb is sliced

func _ready():
	# Add random rotation
	rotation = randf_range(-PI/4, PI/4)
	rotation_speed = randf_range(-2, 2)

func _process(delta):
	# Update position based on velocity
	position += velocity * delta
	
	# Apply gravity to velocity
	velocity.y += gravity * delta
	
	# Update rotation
	rotation += rotation_speed * delta
	
	# Remove if off screen
	if position.y > 800:
		queue_free()

func _on_area_2d_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventScreenDrag or event is InputEventMouseMotion:  # Detects a click
		slice() # Call the slice function to trigger the explosion

# Function to handle slicing of the bomb	
func slice():
	bomb_sliced.emit()  # Emit the signal to inform the game script
	show_explosion()     # Show explosion effect
	queue_free()         # Remove the bomb from the scene after slicing	

# Function to emit "Game Over" effect
func emit_game_over():
	# Assuming there's a dedicated method to trigger Game Over in the main scene
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")  # Replace with your actual Game Over scene path
	
# Function to show the explosion effect
func show_explosion():
	# Create a sprite for the explosion
	var explosion = Sprite2D.new()
	explosion.texture = explosion_texture  # Set the explosion image
	
	# Set the position of the explosion at the bomb's position
	explosion.position = position
	explosion.scale = Vector2(1.0, 1.0)  # Set scale (can adjust for effect)
	explosion.z_index = 1000  # Ensure the explosion appears on top of other objects
	
	# Add explosion to the scene
	get_parent().add_child(explosion)
	
	# Create a tween to animate the explosion
	var tween = explosion.create_tween()
	
	# Animate the explosion to scale up
	tween.tween_property(explosion, "scale", Vector2(1.5, 1.5), 0.5)
	
	# Fade out the explosion
	tween.tween_property(explosion, "modulate:a", 0.0, 0.5)
	
	# Remove the explosion sprite after animation
	tween.finished.connect(func():
		explosion.queue_free())
