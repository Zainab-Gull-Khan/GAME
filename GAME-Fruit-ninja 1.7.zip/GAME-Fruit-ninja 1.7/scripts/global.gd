extends Node

var game_over_label = null  # Store reference to GameOverLabel
# Enum for different fruit types
enum FruitType {APPLE, BANANA, ORANGE, COCONUT, WATERMELON}

# Dictionary storing fruit textures (whole and sliced)
var textures = {
	FruitType.APPLE:{
		"whole": preload("res://assets/images/apple_small.png"),
		"half1": preload("res://assets/images/apple_half_1_small.png"),
		"half2": preload("res://assets/images/apple_half_2_small.png")
	},
	FruitType.BANANA: {
		"whole": preload("res://assets/images/banana_small.png"),
		"half1": preload("res://assets/images/banana_half_1_small.png"),
		"half2": preload("res://assets/images/banana_half_2_small.png")
	},
	FruitType.ORANGE: {
		"whole": preload("res://assets/images/orange_small.png"),
		"half1": preload("res://assets/images/orange_half_1_small.png"),
		"half2": preload("res://assets/images/orange_half_2_small.png")
	},
	FruitType.WATERMELON: {
		"whole": preload("res://assets/images/watermelon_small.png"),
		"half1": preload("res://assets/images/watermelon_half_1_small.png"),
		"half2": preload("res://assets/images/watermelon_half_2_small.png")
	},
	FruitType.COCONUT: {
		"whole": preload("res://assets/images/coconut_small.png"),
		"half1": preload("res://assets/images/coconut_half_1_small.png"),
		"half2": preload("res://assets/images/coconut_half_2_small.png")
	}
}

# Dictionary to store splash effect textures for each fruit type
var splash_textures = {
	FruitType.APPLE: preload("res://assets/images/splash_red_small.png"),
	FruitType.BANANA: preload("res://assets/images/splash_yellow_small.png"),
	FruitType.ORANGE: preload("res://assets/images/splash_orange_small.png"),
	FruitType.WATERMELON: preload("res://assets/images/splash_red_small.png"),
	FruitType.COCONUT: preload("res://assets/images/splash_transparent_small.png")
}

# Global game start sound handling
@onready var game_start_audio = AudioStreamPlayer.new()

func _ready():
	# Preload and set the sound file for the global game start audio
	game_start_audio.stream = preload("res://assets/sounds/game-start-6104.mp3")
	add_child(game_start_audio)  # Attach the audio player to the scene tree

func play_game_start():
	# Play the sound globally without interruption during scene transitions
	game_start_audio.play()

func set_game_over_label(label: Label):
	game_over_label = label
