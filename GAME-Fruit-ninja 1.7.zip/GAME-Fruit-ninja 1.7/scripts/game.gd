extends Node2D

# Constants for game configuration
const MIN_SPAWN_X = 50
const MAX_SPAWN_X = 350
const SPAWN_Y = 700

const INITIAL_Y_VELOCITY = -900
const INITIAL_X_VELOCITY_RANGE = Vector2(-10, 10)

var Fruit = preload("res://scenes/fruit.tscn")
var Bomb = preload("res://scenes/bomb_scene.tscn")  # Don't instantiate globally

# Game state variables
var SPAWN_INTERVAL = 2.0 
var score = 0
var is_game_active = true
var time = 0.0
var time_left = 30
var bobbing_tween = null  
var num_fruits = 1
var is_combo_active = false
var combo_timeout = false
var combo_triggered = false
var last_difficulty_threshold = 0    # For difficulty increments every 15 sec
var last_combo_score = 0             # For triggering combo only once per 100 points

@onready var countdown_label = $countdown_Label
@onready var countdown_timer = $countdown_Timer
@onready var ticking_sound = $TickingAudio
@onready var spawn_timer = $SpawnTimer
@onready var game_over_label = $GameOverLabel
@onready var score_label = $ScoreLabel
@onready var explosion_sound = preload("res://assets/sounds/medium-explosion-40472.mp3")
@onready var combo_label = $ComboLabel
@onready var combo_bar = $ComboProgressBar
@onready var combo1x = $combo1xAudio
@onready var combo_timer = $ComboTimer

func _ready():
	game_over_label.hide()
	spawn_timer.wait_time = SPAWN_INTERVAL
	spawn_timer.start()
	spawn_timer.timeout.connect(_on_spawn_timer_timeout)

	# Initialize countdown timer
	countdown_label.text = str(time_left)
	countdown_timer.wait_time = 1.0
	countdown_timer.start()
	countdown_timer.timeout.connect(_on_countdown_timer_timeout)
	
	# Initialize combo components
	if combo_timer:
		combo_timer.timeout.connect(_on_combo_timer_timeout)
	if combo_label:
		combo_label.text = "COMBO!"
		combo_label.visible = false
	if combo_bar:
		combo_bar.visible = false
	if combo1x:
		combo1x.play()

func _process(delta):
	if is_game_active:
		time += delta
		# Increase difficulty only once every 15 seconds
		var current_threshold = int(time) / 15
		if current_threshold > last_difficulty_threshold:
			last_difficulty_threshold = current_threshold
			increase_difficulty()
		update_timer_effects()

func increase_difficulty():
	if SPAWN_INTERVAL > 0.3:
		SPAWN_INTERVAL -= 0.5
		spawn_timer.wait_time = SPAWN_INTERVAL

func _on_countdown_timer_timeout():
	if time_left > 0:
		time_left -= 1
		countdown_label.text = str(time_left)
		
		if time_left <= 10:
			ticking_sound.play()
			start_bobbing_effect()
			
	if time_left == 0:
		game_over()

func update_timer_effects():
	var color = Color(0, 1, 0)
	if time_left <= 10:
		color = Color(1, 0, 0)
	countdown_label.add_theme_color_override("font_color", color)

func start_bobbing_effect():
	if bobbing_tween:
		bobbing_tween.kill()
	bobbing_tween = get_tree().create_tween()
	var original_pos = countdown_label.position
	var bob_offset = Vector2(3, -3)
	bobbing_tween.tween_property(countdown_label, "position", original_pos + bob_offset, 0.3)\
				 .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.tween_property(countdown_label, "position", original_pos, 0.3)\
				 .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bobbing_tween.set_loops(-1)  # Loop indefinitely

func game_over():
	is_game_active = false
	spawn_timer.stop()
	countdown_timer.stop()
	
	if bobbing_tween:
		bobbing_tween.kill()
		
	game_over_label.show()
	var tween = get_tree().create_tween()
	tween.tween_property(game_over_label, "modulate:a", 1.0, 0.5)\
		 .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(game_over_label, "scale", Vector2(1.2, 1.2), 0.5)\
		 .from(Vector2(0.8, 0.8))\
		 .set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		 
	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/game_over.tscn")

func spawn_fruit():
	if not is_game_active:
		return
		
	for i in range(num_fruits):
		var entity
		if randf() < 0.8:
			entity = Fruit.instantiate()
			entity.fruit_sliced.connect(_on_fruit_sliced)
		else:
			entity = Bomb.instantiate()
			# Connect bomb sliced signal if available on your bomb scene
			entity.bomb_sliced.connect(_on_bomb_sliced)
		
		add_child(entity)
		entity.position = Vector2(randf_range(MIN_SPAWN_X, MAX_SPAWN_X), SPAWN_Y)
		entity.velocity = Vector2(randf_range(INITIAL_X_VELOCITY_RANGE.x, INITIAL_X_VELOCITY_RANGE.y),
								   INITIAL_Y_VELOCITY)
		
		var tween = create_tween()
		tween.tween_property(entity, "scale", Vector2(1, 1), 0.3)\
			 .from(Vector2(0.1, 0.1))\
			 .set_trans(Tween.TRANS_BOUNCE)\
			 .set_ease(Tween.EASE_OUT)

func _on_spawn_timer_timeout():
	spawn_fruit()

func start_combo():
	is_combo_active = true
	combo_timeout = false
	combo_triggered = true  # Mark that the combo has been triggered
	combo_label.text = "COMBO!"
	combo_label.visible = true
	combo_label.scale = Vector2(0.5, 0.5)
	combo_label.modulate.a = 1.0
	combo_bar.visible = true
	combo_bar.value = 0

	if combo1x and not combo1x.playing:
		combo1x.play()
	if combo_timer:
		combo_timer.start()

	var tween = create_tween()
	tween.tween_property(combo_label, "scale", Vector2(1.2, 1.2), 0.3)\
		 .set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tween.tween_property(combo_label, "position", combo_label.position + Vector2(0, -30), 0.5)\
		 .set_delay(0.5).set_trans(Tween.TRANS_SINE)
	tween.finished.connect(func():
		if not is_combo_active:
			combo_label.visible = false
	)

func _on_combo_timer_timeout() -> void:
	combo_timeout = true  # Setting the timeout flag

func _on_fruit_sliced():
	var points = 10
	if is_combo_active:
		points *= 2  # Double the score during combo mode
		
	score += points
	score_label.text = "Score: %d" % score
	score_popup(get_global_mouse_position(), "+%d" % points, Color(0.2, 0.2, 0.2))
	
	# Trigger combo if we've reached a new 100-step threshold.
	if score > 0 and score % 100 == 0 and (score - last_combo_score) >= 100:
		start_combo()
		last_combo_score = score
		
	if is_combo_active:
		if combo_timeout:
			end_combo()
		else:
			if combo_bar:
				combo_bar.value += 10
				if combo_bar.value >= 100:
					end_combo()

# Bomb collision handling (e.g., when the player clicks on the bomb)
func _on_bomb_collision(viewport, event, shape_idx, entity) -> void:
	if event is InputEventMouseButton and event.pressed:
		print("bomb collision detected")
		entity.queue_free()
		_on_bomb_sliced()

func _on_bomb_sliced() -> void:
	# Reduce the remaining time when the bomb is sliced
	time_left -= 10
	if time_left <= 1:
		time_left = 0  # Ensure time doesn't go negative

	# Update the countdown label to reflect the new time
	countdown_label.text = "Time Left: %d" % time_left

	# Popup message to show the deduction
	score_popup(get_global_mouse_position(), "-10 sec", Color(1, 0, 0))
	_screen_shake()

	# Create explosion effect for the bomb
	var explosion: Sprite2D = Sprite2D.new()
	explosion.texture = preload("res://assets/images/explosion_small.png")
	explosion.global_position = get_global_mouse_position()
	add_child(explosion)

	var tween = explosion.create_tween()
	tween.tween_property(explosion, "modulate:a", 0.0, 0.5)\
		 .set_trans(Tween.TRANS_LINEAR)
	tween.finished.connect(func():
		explosion.queue_free())
	
	if is_combo_active:
		end_combo()

func score_popup(pos: Vector2, text: String = "+10", color: Color = Color(0.2, 0.2, 0.2)) -> void:
	var popup: Label = Label.new()
	popup.text = text
	popup.add_theme_font_size_override("font_size", 32)
	popup.add_theme_color_override("font_color", color)
	popup.z_index = 1000

	add_child(popup)
	popup.global_position = pos
	popup.scale = Vector2(0.1, 0.1)
	popup.modulate.a = 1.0

	var tween = popup.create_tween()
	tween.tween_property(popup, "scale", Vector2(1.0, 1.0), 1)\
		 .set_trans(Tween.TRANS_BOUNCE)\
		 .set_ease(Tween.EASE_OUT)

	var target_pos: Vector2 = popup.global_position + Vector2(0, -30)
	tween.parallel().tween_property(popup, "global_position", target_pos, 0.5)\
		 .set_trans(Tween.TRANS_SINE)

	tween.tween_property(popup, "modulate:a", 0.0, 0.4)\
		 .set_trans(Tween.TRANS_SINE)
	tween.finished.connect(func():
		popup.queue_free())

func _screen_shake() -> void:
	# Apply shake to the current scene's root node.
	var root = get_tree().get_current_scene()
	var shake_timer: float = 0.3         # Total shake duration
	var shake_intensity: float = 3.0       # Maximum shake offset
	var original_position: Vector2 = root.position

	while shake_timer > 0:
		var delta: float = get_process_delta_time()
		shake_timer -= delta

		# Generate random offsets
		var offset_x: float = randf_range(-shake_intensity, shake_intensity)
		var offset_y: float = randf_range(-shake_intensity, shake_intensity)

		# Apply the offset relative to the original position
		root.position = original_position + Vector2(offset_x, offset_y)
		await get_tree().create_timer(0.05).timeout

	# Reset the root node to its original position after shaking
	root.position = original_position

func end_combo():
	if not is_combo_active:
		return

	is_combo_active = false
	combo_timeout = false
	if combo_bar:
		combo_bar.visible = false
		combo_bar.value = 0
	combo_label.visible = false
	if combo_timer:
		combo_timer.stop()

	var tween = create_tween()
	tween.tween_property(combo_label, "modulate:a", 0.0, 0.5)\
		 .set_trans(Tween.TRANS_SINE)
	tween.tween_property(combo_label, "position", combo_label.position + Vector2(0, -30), 0.5)\
		 .set_trans(Tween.TRANS_SINE)
	tween.finished.connect(func():
		combo_label.visible = false)

	var audio_player = AudioStreamPlayer.new()
	audio_player.stream = explosion_sound
	add_child(audio_player)
	audio_player.play()
	audio_player.finished.connect(audio_player.queue_free)
